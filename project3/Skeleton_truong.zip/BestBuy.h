// CSCI1300 Fall 2021
// Author: Andrew Truong
// Recitation: 118 – Naga Sai Meenakshi Sistla
// Project 3 

// #ifndef BESTBUY.H //preprocessor activites, when compiling turn these into comments so compilation works
// #define BESTBUY.H

#include <string>
using namespace std;

class BestBuy
{
    private:  //members that cannot be accessed without public functions
    int costCPU;
    int costGPU; 
    int costPowerSupplyUnit;
    int costComputerCase;
    int costInternetCard;
    int costKeyboardAndMouse;
    int costPremadeComputer;

    public: //members that can access private members
    BestBuy(); //default constuctor
    BestBuy(int costCPU, int costGPU, int costPowerSupplyUnit, int costComputerCase, int costInternetCard, int costKeyboardAndMouse, int costPremadeComputer); //parameterized constructor
    int getCostCPU();
    void setCostCPU(int costCPU);
    int getCostGPU();
    void setCostGPU(int costGPU);
    int getCostPowerSupplyUnit();
    void setCostPowerSupplyUnit(int costPowerSupplyUnit);
    int getCostComputerCase();
    void setCostComputerCase(int costComputerCase);
    int getCostInternetCard();
    void setCostInternetCard(int costInternetCard);
    int getCostKeyboardAndMouse();
    void setCostKeyboardAndMouse(int costKeyboardAndMouse);
    int getCostPremadeComputer();
    void setCostPremadeComputer(int costPremadeComputer);

};

// #endif
