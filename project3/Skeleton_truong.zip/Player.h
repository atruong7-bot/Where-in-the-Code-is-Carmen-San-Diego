// CSCI1300 Fall 2021
// Author: Andrew Truong
// Recitation: 118 – Naga Sai Meenakshi Sistla
// Project 3 

// #ifndef PLAYER.H //preprocessor activites, when compiling turn these into comments so compilation works
// #define PLAYER.H 

#include <string>
using namespace std;

class Player
{
    private: //members that cannot be accessed without public functions
    string playerName;
    int frustrationLevel;
    int dogeCoins;
    int internetProviderLevel;
    int numOfVPN;
    int computer;
    int computerParts;
    int antivirusSoftware;

    public: //members that can access private members
    Player(); //default constructor
    Player(string playerName, int frustrationLevel, int dogeCoins, int internetProviderLevel, int numOfVPN, int computer, int computerParts, int antivirusSoftware); //parameterized constructor
    string getPlayerName();
    void setPlayerName(string name);
    int getFrustrationLevel();
    void setFrustrationLevel(int frustrationLevel);
    int getDogeCoins();
    void setDogeCoins(int dogeCoins);
    int getInternetProviderLevel();
    void setInternetProviderLevel(int internetProviderLevel);
    int getNumOfVPN();
    void setNumOfVPN(int numOfVPN);
    int getComputer();
    void setComputer(int computer);
    int getComputerParts();
    void setComputerParts(int computerParts);
    int getAntivirusSoftware();
    void setAntivirusSoftware(int antivirusSoftware);




};

// #endif