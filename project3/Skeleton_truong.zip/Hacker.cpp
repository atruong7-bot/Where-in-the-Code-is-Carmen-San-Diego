// CSCI1300 Fall 2021
// Author: Andrew Truong
// Recitation: 118 – Naga Sai Meenakshi Sistla
// Project 3

#include "Hacker.h"
#include <iostream>


using namespace std;

//constructors
Hacker::Hacker()
{
    name = "Hacker";
    serverRoomNumber = 0;
    progressLevelCarmen = 0;
}

Hacker::Hacker(string name_, int serverRoomNumber_, int progressLevelCarmen_)
{
    name = name_;
    serverRoomNumber = serverRoomNumber_;
    progressLevelCarmen = progressLevelCarmen_;
}

//getters/setters

string Hacker::getName()
{
    return name;
}

void Hacker::setName(string setName)
{
    name = setName;
}

int Hacker::getServerRoomNumber()
{
    return serverRoomNumber;
}

void Hacker::setServerRoomNumber(int setServerRoomNumber)
{
    serverRoomNumber = setServerRoomNumber;
}

int Hacker::getProgressLevelCarmen()
{
    return progressLevelCarmen;
}

void Hacker::setProgressLevelCarmen(int setProgressLevelCarmen)
{
    progressLevelCarmen = setProgressLevelCarmen;
}

